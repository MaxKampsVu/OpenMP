void start_roi();
void end_roi();
void barrier();
