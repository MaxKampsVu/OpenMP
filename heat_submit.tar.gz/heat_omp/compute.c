#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>
#include <float.h>
#include <time.h>

#include "compute.h"
#include "fail.h"
#include "input.h"
#include "annotation.h"

/* ... */

void do_compute(const struct parameters* p, struct results *r) {
    /* ... */
}

