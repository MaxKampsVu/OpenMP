#include <stdio.h>

void start_roi() { /* printf("start roi\n"); */ }
void end_roi() { /* printf("end roi\n"); */ }
void barrier() {};
