#include "compute.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

void do_compute(const struct parameters *p, struct results *r) {
    size_t N = p->N, M = p->M;
    double *current = malloc(N * M * sizeof(double));
    double *next = malloc(N * M * sizeof(double));
    memcpy(current, p->tinit, N * M * sizeof(double));

    size_t iter;
    double maxdiff, tmin, tmax, tavg;

    for (iter = 0; iter < p->maxiter; iter++) {
        maxdiff = 0.0;
        tmin = INFINITY;
        tmax = -INFINITY;
        tavg = 0.0;

        for (size_t i = 1; i < N - 1; i++) {
            for (size_t j = 0; j < M; j++) {
                size_t left = (j == 0) ? M - 1 : j - 1;
                size_t right = (j == M - 1) ? 0 : j + 1;

                double conductivity = p->conductivity[i * M + j];
                double weight_direct = (1.0 - conductivity) * (2.0 / (2.0 + 1.414));
                double weight_diag = (1.0 - conductivity) * (1.414 / (2.0 + 1.414));

                double tnew = conductivity * current[i * M + j] +
                              weight_direct * (current[i * M + left] + current[i * M + right] +
                                               current[(i - 1) * M + j] + current[(i + 1) * M + j]) / 4.0 +
                              weight_diag * (current[(i - 1) * M + left] + current[(i - 1) * M + right] +
                                             current[(i + 1) * M + left] + current[(i + 1) * M + right]) / 4.0;

                maxdiff = fmax(maxdiff, fabs(tnew - current[i * M + j]));
                next[i * M + j] = tnew;

                tmin = fmin(tmin, tnew);
                tmax = fmax(tmax, tnew);
                tavg += tnew;
            }
        }

        tavg /= (N * M);
        double *temp = current;
        current = next;
        next = temp;

        if (iter % p->period == 0 || maxdiff < p->threshold) {
            r->niter = iter + 1;
            r->maxdiff = maxdiff;
            r->tmin = tmin;
            r->tmax = tmax;
            r->tavg = tavg;
        }

        if (maxdiff < p->threshold) {
            break;
        }
    }

    free(current);
    free(next);
}
